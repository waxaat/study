grades = [" 5 ", 'неявка', "4", " хор ", " ", "100", "2", "два"]
grades_list = {'5': 5, '4': 4, '3': 3, '2': 2, "отл": 5, "хор": 4, "уд": 3, "неуд": 2}
result = sorted([grades_list[g] for g in (x.strip() for x in grades) if g in grades_list], reverse=True)
print(result)